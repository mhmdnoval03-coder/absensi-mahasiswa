<?php
// Konfigurasi database (XAMPP default: user root, tanpa password)
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
date_default_timezone_set('Asia/Jakarta');

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'db_absensi_mahasiswa');

// Path folder proyek terhadap htdocs, dihitung otomatis (contoh: /absensi-mahasiswa)
$_root = str_replace('\\', '/', realpath(__DIR__ . '/..'));
$_doc  = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '');
define('BASE_PATH', ($_doc !== '' && stripos($_root, $_doc) === 0) ? rtrim(substr($_root, strlen($_doc)), '/') : '');

function koneksi(): mysqli
{
    static $conn = null;
    if ($conn instanceof mysqli) return $conn;
    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $conn->set_charset('utf8mb4');
        $conn->query("SET time_zone = '+07:00'");
        return $conn;
    } catch (mysqli_sql_exception $e) {
        tampil_error('Koneksi database gagal',
            'Aplikasi tidak dapat terhubung ke database. Pastikan MySQL di XAMPP sudah dijalankan dan database <b>' . DB_NAME . '</b> sudah diimpor.');
    }
}

function tampil_error(string $judul, string $pesan): void
{
    http_response_code(500);
    die('<!DOCTYPE html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Terjadi Kesalahan</title></head>
<body style="font-family:Segoe UI,Arial,sans-serif;background:#F4F7FB;padding:32px 16px">
<div style="max-width:520px;margin:auto;background:#fff;border-left:6px solid #C0392B;padding:24px;border-radius:6px">
<h2 style="color:#0A2540;margin-top:0">' . $judul . '</h2><p>' . $pesan . '</p></div></body></html>');
}
