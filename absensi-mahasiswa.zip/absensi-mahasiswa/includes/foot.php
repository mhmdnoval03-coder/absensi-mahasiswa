<script src="<?= url('assets/vendor/bootstrap.bundle.min.js') ?>"></script>
<script src="<?= url('assets/vendor/sweetalert2.all.min.js') ?>"></script>
<?php foreach (($libs ?? []) as $l): ?><script src="<?= url('assets/vendor/' . $l) ?>"></script><?php endforeach; ?>
<script src="<?= url('assets/js/app.js') ?>"></script>
<?php if (!empty($_SESSION['flash'])): [$ft, $fm] = $_SESSION['flash']; unset($_SESSION['flash']); ?>
<script>Swal.fire({icon: <?= json_encode($ft) ?>, html: <?= json_encode(nl2br(e($fm))) ?>, confirmButtonColor: '#1F4E8C', confirmButtonText: 'OK'});</script>
<?php endif; ?>
</body></html>
