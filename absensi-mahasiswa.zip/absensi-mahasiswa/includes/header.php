<?php
// Kerangka halaman admin: butuh $judul dan $aktif
cek_login();
include __DIR__ . '/head.php';
$menu = [
    'dashboard.php' => ['Dashboard', '🏠'], 'kegiatan.php' => ['Kegiatan', '📅'],
    'mahasiswa.php' => ['Mahasiswa', '🎓'], 'rekap.php' => ['Rekapitulasi', '📊'],
];
?>
<div class="layout">
<aside class="sidebar">
  <div class="brand"><div class="logo">✅</div><div>Absensi Kegiatan<small>Panel Admin</small></div></div>
  <div class="sec">Menu utama</div>
  <nav>
    <?php foreach ($menu as $f => [$l, $i]): ?>
      <a class="<?= ($aktif ?? '') === $f ? 'active' : '' ?>" href="<?= url('admin/' . $f) ?>"><span><?= $i ?></span><?= $l ?></a>
    <?php endforeach; ?>
    <div class="sec">Lainnya</div>
    <a href="<?= url('index.php') ?>" target="_blank"><span>🌐</span>Halaman Publik</a>
    <a href="<?= url('logout.php') ?>"><span>🚪</span>Keluar</a>
  </nav>
</aside>
<main class="content">
  <div class="topbar">
    <button id="toggleSidebar" class="btn btn-outline-primary d-lg-none" aria-label="Menu">☰</button>
    <h1><?= e($judul) ?></h1>
    <span class="userchip ms-auto"><i><?= e(strtoupper(substr($_SESSION['admin']['nama'], 0, 1))) ?></i><?= e($_SESSION['admin']['nama']) ?></span>
  </div>
