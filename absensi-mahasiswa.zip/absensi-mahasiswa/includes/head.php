<?php $judul = $judul ?? 'Absensi'; ?><!DOCTYPE html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($judul) ?> | Absensi Kegiatan Mahasiswa</title>
<link rel="stylesheet" href="<?= url('assets/vendor/bootstrap.min.css') ?>">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
</head><body class="<?= e($bodyClass ?? '') ?>">
