</main></div>
<?php include __DIR__ . '/foot.php'; ?>
