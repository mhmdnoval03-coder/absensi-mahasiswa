<?php
require_once __DIR__ . '/../config/database.php';
if (session_status() === PHP_SESSION_NONE) session_start();

// Kesalahan tak terduga tampil sebagai pesan, bukan halaman kosong
set_exception_handler(function ($e) {
    error_log('[absensi] ' . $e->getMessage());
    tampil_error('Terjadi kesalahan', 'Proses tidak dapat diselesaikan. Silakan muat ulang halaman atau hubungi admin.');
});

const STATUS_HADIR = ['Hadir', 'Izin', 'Sakit', 'Alpa'];
const ABSEN_BUKA_SEBELUM = 30; // menit sebelum jam mulai absensi sudah boleh dibuka

// Perbaikan D-01: absensi hanya sah pada hari kegiatan, dari (jam mulai - 30 menit) sampai jam selesai
function jendela_absen(array $k): array
{
    $mulai   = strtotime($k['tanggal'] . ' ' . $k['jam_mulai']) - ABSEN_BUKA_SEBELUM * 60;
    $selesai = strtotime($k['tanggal'] . ' ' . $k['jam_selesai']);
    $now     = time();
    if ($now < $mulai)   return [false, 'Absensi belum dibuka. Absensi dibuka mulai ' . date('d-m-Y H:i', $mulai) . ' WIB.'];
    if ($now > $selesai) return [false, 'Waktu absensi sudah berakhir pada ' . date('d-m-Y H:i', $selesai) . ' WIB.'];
    return [true, ''];
}

// Perbaikan D-03: cegah CSV/Formula Injection saat dibuka di Excel
function csv_aman($v)
{
    if (!is_string($v)) return $v;
    return preg_match('/^[=+\-@\t\r]/', $v) ? "'" . $v : $v;
}

function panjang(string $s): int { return function_exists('mb_strlen') ? mb_strlen($s) : strlen($s); }
function e($s): string { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function url(string $p = ''): string { return BASE_PATH . '/' . ltrim($p, '/'); }
function redirect(string $u): void { header('Location: ' . $u); exit; }
function flash(string $type, string $msg): void { $_SESSION['flash'] = [$type, $msg]; }
function tgl(?string $d): string { return $d ? date('d-m-Y', strtotime($d)) : '-'; }
function jam(?string $j): string { return $j ? substr($j, 0, 5) : '-'; }

function cek_login(): void
{
    if (empty($_SESSION['admin'])) {
        flash('warning', 'Silakan login terlebih dahulu.');
        redirect(url('login.php'));
    }
}

// Query aman (prepared statement)
function q(string $sql, string $types = '', array $p = []): mysqli_stmt
{
    $st = koneksi()->prepare($sql);
    if ($types !== '') $st->bind_param($types, ...$p);
    $st->execute();
    return $st;
}
function rows(string $sql, string $types = '', array $p = []): array { return q($sql, $types, $p)->get_result()->fetch_all(MYSQLI_ASSOC); }
function row(string $sql, string $types = '', array $p = []): ?array { return rows($sql, $types, $p)[0] ?? null; }

function badge(?string $s): string
{
    $map = ['Hadir' => 'success', 'Izin' => 'info', 'Sakit' => 'warning', 'Alpa' => 'danger', 'dibuka' => 'success', 'ditutup' => 'secondary'];
    $s = $s ?? 'Belum tercatat';
    return '<span class="badge text-bg-' . ($map[$s] ?? 'light') . '">' . e($s) . '</span>';
}

// Daftar peserta = seluruh mahasiswa terdaftar, lengkap dengan status pada kegiatan terpilih
function peserta(int $kid): array
{
    return rows("SELECT m.id, m.nim, m.nama, m.prodi, a.status, a.waktu_absen, a.metode
                 FROM mahasiswa m LEFT JOIN absensi a ON a.mahasiswa_id = m.id AND a.kegiatan_id = ?
                 ORDER BY m.nim", 'i', [$kid]);
}
function ringkas(array $list): array
{
    $c = ['Hadir' => 0, 'Izin' => 0, 'Sakit' => 0, 'Alpa' => 0, 'Belum' => 0];
    foreach ($list as $r) $c[$r['status'] ?? 'Belum']++;
    $c['total'] = count($list);
    $c['tidak_hadir'] = $c['total'] - $c['Hadir'];
    $c['persen'] = $c['total'] ? round($c['Hadir'] / $c['total'] * 100, 1) : 0;
    return $c;
}
