<?php
require __DIR__ . '/../includes/functions.php';
$token = $_GET['token'] ?? '';
$k = preg_match('/^[0-9a-f]{32}$/', $token)
    ? row("SELECT k.* FROM qr_tokens t JOIN kegiatan k ON k.id = t.kegiatan_id WHERE t.token = ?", 's', [$token]) : null;

$jendela = ($k && $k['status'] === 'dibuka') ? jendela_absen($k) : [false, ''];

if ($k && $k['status'] === 'dibuka' && $jendela[0] && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $nim = trim($_POST['nim'] ?? '');
    if ($nim === '') flash('error', 'NIM wajib diisi.');
    elseif (!preg_match('/^[0-9A-Za-z]{5,20}$/', $nim)) flash('error', 'Format NIM tidak valid (5–20 huruf atau angka).');
    else {
        $m = row("SELECT * FROM mahasiswa WHERE nim = ?", 's', [$nim]);
        if (!$m) flash('error', 'Mahasiswa belum terdaftar. Hubungi panitia.');
        else {
            $ada = row("SELECT waktu_absen FROM absensi WHERE kegiatan_id = ? AND mahasiswa_id = ?", 'ii', [$k['id'], $m['id']]);
            if ($ada) flash('warning', 'Absensi ' . $m['nama'] . ' sudah tercatat pada ' . date('d-m-Y H:i', strtotime($ada['waktu_absen'])) . '.');
            else {
                try {
                    q("INSERT INTO absensi (kegiatan_id, mahasiswa_id, status, metode) VALUES (?,?,'Hadir','QR')", 'ii', [$k['id'], $m['id']]);
                    flash('success', 'Absensi berhasil. Terima kasih, ' . $m['nama'] . '!');
                } catch (mysqli_sql_exception $e) {
                    flash($e->getCode() == 1062 ? 'warning' : 'error', $e->getCode() == 1062 ? 'Absensi sudah tercatat sebelumnya.' : 'Gagal menyimpan absensi. Silakan coba lagi.');
                }
            }
        }
    }
    redirect('absen.php?token=' . $token);
}
$judul = 'Absensi'; $bodyClass = '';
include __DIR__ . '/../includes/head.php';
?>
<div class="auth"><div class="panel">
<?php if (!$k): ?>
  <h1 class="h4 fw-bold text-danger">QR Code tidak valid</h1>
  <p class="mb-0">Kode yang dipindai tidak dikenali. Pindai ulang QR Code dari panitia kegiatan.</p>
<?php elseif ($k['status'] !== 'dibuka'): ?>
  <h1 class="h4 fw-bold" style="color:var(--navy)"><?= e($k['nama_kegiatan']) ?></h1>
  <div class="alert alert-secondary mt-3 mb-0">Kegiatan ini sudah ditutup, absensi tidak dapat dilakukan.</div>
<?php elseif (!$jendela[0]): ?>
  <h1 class="h4 fw-bold" style="color:var(--navy)"><?= e($k['nama_kegiatan']) ?></h1>
  <p class="text-muted"><?= tgl($k['tanggal']) ?>, <?= jam($k['jam_mulai']) ?>–<?= jam($k['jam_selesai']) ?><br><?= e($k['lokasi']) ?></p>
  <div class="alert alert-warning mt-3 mb-0"><?= e($jendela[1]) ?></div>
<?php else: ?>
  <h1 class="h4 fw-bold" style="color:var(--navy)"><?= e($k['nama_kegiatan']) ?></h1>
  <p class="text-muted"><?= tgl($k['tanggal']) ?>, <?= jam($k['jam_mulai']) ?>–<?= jam($k['jam_selesai']) ?><br><?= e($k['lokasi']) ?></p>
  <form method="post" class="needs-validation" novalidate>
    <label class="form-label">Masukkan NIM</label>
    <input name="nim" class="form-control form-control-lg mb-3" inputmode="text" required pattern="[0-9A-Za-z]{5,20}" maxlength="20" autofocus>
    <div class="invalid-feedback mb-2">NIM wajib diisi (5–20 huruf/angka).</div>
    <button class="btn btn-primary btn-lg w-100">Absen sekarang</button>
  </form>
<?php endif; ?>
  <a href="riwayat.php" class="d-block text-center mt-3 small">Lihat riwayat absensi</a>
</div></div>
<?php include __DIR__ . '/../includes/foot.php';
