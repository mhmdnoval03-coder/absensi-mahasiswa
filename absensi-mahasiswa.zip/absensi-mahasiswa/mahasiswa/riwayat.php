<?php
require __DIR__ . '/../includes/functions.php';
$q = trim($_GET['q'] ?? ''); $m = null; $list = []; $c = null; $pilihan = [];
if (isset($_GET['q'])) {
    if ($q === '') flash('error', 'Masukkan NIM atau nama mahasiswa.');
    elseif (panjang($q) < 3) flash('error', 'Ketik minimal 3 karakter NIM atau nama.');
    else {
        // 1) cocokkan NIM persis, 2) jika tidak ada, cari berdasarkan nama atau sebagian NIM
        $m = row("SELECT * FROM mahasiswa WHERE nim = ?", 's', [$q]);
        if (!$m) {
            $like = '%' . addcslashes($q, '%_') . '%';
            $cari = rows("SELECT * FROM mahasiswa WHERE nama LIKE ? OR nim LIKE ? ORDER BY nama LIMIT 20", 'ss', [$like, $like]);
            if (count($cari) === 1) $m = $cari[0];
            elseif (count($cari) > 1) $pilihan = $cari;
            else flash('error', 'Mahasiswa dengan NIM atau nama tersebut belum terdaftar.');
        }
    }
    if ($m) {
        // Semua kegiatan, lengkap dengan status kehadiran mahasiswa ini (kosong jika belum tercatat)
        $list = rows("SELECT k.nama_kegiatan, k.tanggal, k.jam_mulai, k.lokasi, a.status, a.waktu_absen
                      FROM kegiatan k LEFT JOIN absensi a ON a.kegiatan_id = k.id AND a.mahasiswa_id = ?
                      ORDER BY k.tanggal DESC, k.jam_mulai DESC", 'i', [$m['id']]);
        $c = ['Hadir' => 0, 'Izin' => 0, 'Sakit' => 0, 'Alpa' => 0, 'Belum' => 0, 'dihitung' => 0];
        $hari = date('Y-m-d');
        foreach ($list as $i => $r) {
            $berlangsung = $r['tanggal'] <= $hari || $r['status'] !== null;
            $list[$i]['berlangsung'] = $berlangsung;
            if ($r['status'] !== null) $c[$r['status']]++;
            elseif ($berlangsung) $c['Belum']++;
            if ($berlangsung) $c['dihitung']++;
        }
        $c['persen'] = $c['dihitung'] ? round($c['Hadir'] / $c['dihitung'] * 100, 1) : 0;
    }
}
$judul = 'Riwayat Absensi'; $bodyClass = '';
include __DIR__ . '/../includes/head.php';
?>
<div class="hero"><div class="container" style="max-width:900px">
  <a href="<?= url('index.php') ?>" class="btn-back">← Kembali</a>
  <h1>Riwayat Absensi</h1>
  <form class="d-flex gap-2"><input name="q" class="form-control" placeholder="Masukkan NIM atau nama" value="<?= e($q) ?>" required minlength="3">
  <button class="btn btn-light">Lihat</button></form></div></div>
<div class="pub" style="max-width:900px">
<?php if ($pilihan): ?>
  <div class="panel mb-3">
    <h2 class="h6 fw-bold">Ditemukan <?= count($pilihan) ?> mahasiswa. Pilih salah satu:</h2>
    <div class="list-group">
    <?php foreach ($pilihan as $x): ?>
      <a class="list-group-item list-group-item-action" href="?q=<?= urlencode($x['nim']) ?>"><b><?= e($x['nama']) ?></b>
        <span class="text-muted">· NIM <?= e($x['nim']) ?> · <?= e($x['prodi'] ?: '-') ?></span></a>
    <?php endforeach; ?></div>
    <?php if (count($pilihan) === 20): ?><p class="small text-muted mt-2 mb-0">Hanya 20 hasil pertama yang ditampilkan. Ketik nama atau NIM lebih lengkap.</p><?php endif; ?>
  </div>
<?php endif; ?>
<?php if ($m): ?>
  <div class="panel mb-3">
    <h2 class="h5 fw-bold mb-1" style="color:var(--navy)"><?= e($m['nama']) ?></h2>
    <div class="text-muted">NIM <?= e($m['nim']) ?> · <?= e($m['prodi'] ?: 'Program studi belum diisi') ?></div>
  </div>
  <div class="row g-2 mb-3">
    <?php foreach ([['Hadir', $c['Hadir']], ['Izin', $c['Izin']], ['Sakit', $c['Sakit']], ['Alpa', $c['Alpa']], ['Belum tercatat', $c['Belum']], ['Persentase hadir', $c['persen'] . '%']] as [$l, $n]): ?>
    <div class="col-6 col-md-2"><div class="stat"><div class="n"><?= $n ?></div><div class="l"><?= $l ?></div></div></div>
    <?php endforeach; ?>
  </div>
  <div class="panel">
    <h2 class="h6 fw-bold mb-3">Semua kegiatan</h2>
    <?php if (!$list): ?><p class="text-muted mb-0">Belum ada kegiatan.</p><?php else: ?>
    <div class="table-responsive"><table class="table align-middle mb-0">
      <thead><tr><th>Kegiatan</th><th>Tanggal</th><th>Lokasi</th><th>Status</th><th>Waktu absen</th></tr></thead><tbody>
      <?php foreach ($list as $r): ?>
        <tr><td><?= e($r['nama_kegiatan']) ?></td><td><?= tgl($r['tanggal']) ?></td><td><?= e($r['lokasi']) ?></td>
        <td><?php if ($r['status'] !== null) echo badge($r['status']);
                  elseif ($r['berlangsung']) echo '<span class="badge text-bg-light border">Belum tercatat</span>';
                  else echo '<span class="badge text-bg-light border text-muted">Belum berlangsung</span>'; ?></td>
        <td><?= $r['waktu_absen'] ? date('d-m-Y H:i', strtotime($r['waktu_absen'])) : '-' ?></td></tr>
      <?php endforeach; ?></tbody></table></div>
    <p class="small text-muted mt-3 mb-0">Persentase = jumlah Hadir ÷ kegiatan yang sudah berlangsung (<?= $c['dihitung'] ?> kegiatan).</p>
    <?php endif; ?>
  </div>
<?php elseif (!$pilihan): ?>
  <div class="panel text-muted">Masukkan NIM atau nama untuk melihat ringkasan dan riwayat kehadiran.</div>
<?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/foot.php';
