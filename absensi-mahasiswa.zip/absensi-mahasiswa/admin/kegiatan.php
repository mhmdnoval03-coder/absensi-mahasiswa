<?php
require __DIR__ . '/../includes/functions.php';
cek_login();
$aksi = $_GET['aksi'] ?? '';
$form = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $a = $_POST['aksi'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    if ($a === 'hapus') {
        try {
            $r = q("DELETE FROM kegiatan WHERE id = ?", 'i', [$id]);
            $r->affected_rows ? flash('success', 'Kegiatan berhasil dihapus.') : flash('error', 'Data kegiatan tidak ditemukan.');
        } catch (mysqli_sql_exception $e) { flash('error', 'Gagal menghapus kegiatan. Silakan coba lagi.'); }
        redirect('kegiatan.php');
    }
    if ($a === 'simpan') {
        $d = ['nama_kegiatan' => trim($_POST['nama_kegiatan'] ?? ''), 'deskripsi' => trim($_POST['deskripsi'] ?? ''),
              'tanggal' => $_POST['tanggal'] ?? '', 'jam_mulai' => $_POST['jam_mulai'] ?? '', 'jam_selesai' => $_POST['jam_selesai'] ?? '',
              'lokasi' => trim($_POST['lokasi'] ?? ''), 'status' => $_POST['status'] ?? 'dibuka'];
        $err = [];
        if ($d['nama_kegiatan'] === '') $err[] = 'Nama kegiatan wajib diisi.';
        elseif (panjang($d['nama_kegiatan']) > 150) $err[] = 'Nama kegiatan maksimal 150 karakter.';
        $dt = DateTime::createFromFormat('Y-m-d', $d['tanggal']);
        if (!$dt || $dt->format('Y-m-d') !== $d['tanggal']) $err[] = 'Tanggal tidak valid.';
        elseif ($d['tanggal'] < '2020-01-01' || $d['tanggal'] > date('Y-m-d', strtotime('+5 years'))) $err[] = 'Tanggal kegiatan harus antara 01-01-2020 dan 5 tahun ke depan.'; // perbaikan D-02
        if (!preg_match('/^\d{2}:\d{2}$/', $d['jam_mulai']) || !preg_match('/^\d{2}:\d{2}$/', $d['jam_selesai'])) $err[] = 'Jam mulai dan jam selesai wajib diisi.';
        elseif ($d['jam_selesai'] <= $d['jam_mulai']) $err[] = 'Jam selesai harus lebih besar dari jam mulai.';
        if ($d['lokasi'] === '') $err[] = 'Lokasi wajib diisi.';
        if (!in_array($d['status'], ['dibuka', 'ditutup'], true)) $err[] = 'Status kegiatan tidak valid.';
        if (!$err) {
            try {
                $v = [$d['nama_kegiatan'], $d['deskripsi'], $d['tanggal'], $d['jam_mulai'] . ':00', $d['jam_selesai'] . ':00', $d['lokasi'], $d['status']];
                if ($id) {
                    q("UPDATE kegiatan SET nama_kegiatan=?, deskripsi=?, tanggal=?, jam_mulai=?, jam_selesai=?, lokasi=?, status=? WHERE id=?", 'sssssssi', [...$v, $id]);
                    flash('success', 'Kegiatan berhasil diperbarui.');
                } else {
                    q("INSERT INTO kegiatan (nama_kegiatan, deskripsi, tanggal, jam_mulai, jam_selesai, lokasi, status) VALUES (?,?,?,?,?,?,?)", 'sssssss', $v);
                    $new = koneksi()->insert_id;
                    q("INSERT INTO qr_tokens (kegiatan_id, token) VALUES (?, ?)", 'is', [$new, bin2hex(random_bytes(16))]);
                    flash('success', 'Kegiatan berhasil ditambahkan.');
                }
                redirect('kegiatan.php');
            } catch (mysqli_sql_exception $e) { $err[] = 'Gagal menyimpan data. Silakan coba lagi.'; }
        }
        flash('error', implode("\n", $err));
        $form = $d; $aksi = 'form'; $_GET['id'] = $id;
    }
}

$judul = 'Manajemen Kegiatan'; $aktif = 'kegiatan.php';
if ($aksi === 'form') {
    $id = (int)($_GET['id'] ?? 0);
    if ($form === null) {
        $form = ['nama_kegiatan' => '', 'deskripsi' => '', 'tanggal' => date('Y-m-d'), 'jam_mulai' => '08:00', 'jam_selesai' => '10:00', 'lokasi' => '', 'status' => 'dibuka'];
        if ($id) {
            $r = row("SELECT * FROM kegiatan WHERE id = ?", 'i', [$id]);
            if (!$r) { flash('error', 'Data kegiatan tidak ditemukan.'); redirect('kegiatan.php'); }
            $form = array_merge($r, ['jam_mulai' => jam($r['jam_mulai']), 'jam_selesai' => jam($r['jam_selesai'])]);
        }
    }
    include __DIR__ . '/../includes/header.php';
?>
<div class="panel" style="max-width:760px">
<h2 class="h5 fw-bold mb-3"><?= $id ? 'Edit kegiatan' : 'Tambah kegiatan' ?></h2>
<form method="post" class="needs-validation" novalidate>
  <input type="hidden" name="aksi" value="simpan"><input type="hidden" name="id" value="<?= $id ?>">
  <div class="mb-3"><label class="form-label">Nama kegiatan</label>
    <input name="nama_kegiatan" class="form-control" maxlength="150" required value="<?= e($form['nama_kegiatan']) ?>">
    <div class="invalid-feedback">Nama kegiatan wajib diisi.</div></div>
  <div class="mb-3"><label class="form-label">Deskripsi</label><textarea name="deskripsi" rows="3" class="form-control"><?= e($form['deskripsi']) ?></textarea></div>
  <div class="row g-3 mb-3">
    <div class="col-md-4"><label class="form-label">Tanggal</label><input type="date" name="tanggal" class="form-control" required value="<?= e($form['tanggal']) ?>"></div>
    <div class="col-md-4"><label class="form-label">Jam mulai</label><input type="time" name="jam_mulai" class="form-control" required value="<?= e($form['jam_mulai']) ?>"></div>
    <div class="col-md-4"><label class="form-label">Jam selesai</label><input type="time" name="jam_selesai" class="form-control" required value="<?= e($form['jam_selesai']) ?>"></div>
  </div>
  <div class="row g-3 mb-4">
    <div class="col-md-8"><label class="form-label">Lokasi</label><input name="lokasi" class="form-control" maxlength="150" required value="<?= e($form['lokasi']) ?>">
      <div class="invalid-feedback">Lokasi wajib diisi.</div></div>
    <div class="col-md-4"><label class="form-label">Status</label><select name="status" class="form-select">
      <?php foreach (['dibuka', 'ditutup'] as $o): ?><option value="<?= $o ?>" <?= $form['status'] === $o ? 'selected' : '' ?>><?= ucfirst($o) ?></option><?php endforeach; ?></select></div>
  </div>
  <button class="btn btn-primary">Simpan kegiatan</button> <a href="kegiatan.php" class="btn btn-outline-secondary">Batal</a>
</form></div>
<?php include __DIR__ . '/../includes/footer.php'; exit; }

$cari = trim($_GET['q'] ?? ''); $fs = $_GET['status'] ?? '';
$sql = "SELECT k.*, (SELECT COUNT(*) FROM absensi a WHERE a.kegiatan_id = k.id AND a.status='Hadir') hadir FROM kegiatan k WHERE (k.nama_kegiatan LIKE ? OR k.lokasi LIKE ?)";
$t = 'ss'; $p = ["%$cari%", "%$cari%"];
if (in_array($fs, ['dibuka', 'ditutup'], true)) { $sql .= " AND k.status = ?"; $t .= 's'; $p[] = $fs; }
$list = rows($sql . " ORDER BY k.tanggal DESC, k.jam_mulai DESC", $t, $p);
include __DIR__ . '/../includes/header.php';
?>
<div class="panel">
  <form class="row g-2 mb-3" method="get">
    <div class="col-md-5"><input name="q" class="form-control" placeholder="Cari nama atau lokasi kegiatan" value="<?= e($cari) ?>"></div>
    <div class="col-md-3"><select name="status" class="form-select"><option value="">Semua status</option>
      <?php foreach (['dibuka', 'ditutup'] as $o): ?><option value="<?= $o ?>" <?= $fs === $o ? 'selected' : '' ?>><?= ucfirst($o) ?></option><?php endforeach; ?></select></div>
    <div class="col-md-4 d-flex gap-2"><button class="btn btn-primary">Cari</button><a href="kegiatan.php" class="btn btn-outline-secondary">Reset</a>
      <a href="kegiatan.php?aksi=form" class="btn btn-success ms-auto">+ Tambah</a></div>
  </form>
  <div class="table-responsive"><table class="table align-middle">
    <thead><tr><th>#</th><th>Kegiatan</th><th>Tanggal</th><th>Waktu</th><th>Lokasi</th><th>Hadir</th><th>Status</th><th>Aksi</th></tr></thead><tbody>
    <?php foreach ($list as $i => $k): ?>
      <tr><td><?= $i + 1 ?></td><td class="fw-semibold"><?= e($k['nama_kegiatan']) ?></td><td><?= tgl($k['tanggal']) ?></td>
      <td><?= jam($k['jam_mulai']) ?>–<?= jam($k['jam_selesai']) ?></td><td><?= e($k['lokasi']) ?></td><td><?= $k['hadir'] ?></td><td><?= badge($k['status']) ?></td>
      <td class="text-nowrap">
        <a class="btn btn-sm btn-outline-primary" href="detail.php?id=<?= $k['id'] ?>">Detail</a>
        <a class="btn btn-sm btn-outline-dark" href="qr.php?id=<?= $k['id'] ?>">QR</a>
        <a class="btn btn-sm btn-outline-secondary" href="kegiatan.php?aksi=form&id=<?= $k['id'] ?>">Edit</a>
        <form method="post" class="d-inline js-hapus" data-pesan="Semua data absensi pada kegiatan ini ikut terhapus.">
          <input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= $k['id'] ?>"><button class="btn btn-sm btn-outline-danger">Hapus</button></form>
      </td></tr>
    <?php endforeach; if (!$list): ?><tr><td colspan="8" class="text-center text-muted py-4">Data kegiatan tidak ditemukan.</td></tr><?php endif; ?>
    </tbody></table></div>
</div>
<?php include __DIR__ . '/../includes/footer.php';
