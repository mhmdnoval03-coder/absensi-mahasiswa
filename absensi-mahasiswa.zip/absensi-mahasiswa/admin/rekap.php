<?php
require __DIR__ . '/../includes/functions.php';
$judul = 'Rekapitulasi Kehadiran'; $aktif = 'rekap.php';
$kegiatan = rows("SELECT id, nama_kegiatan, tanggal FROM kegiatan ORDER BY tanggal DESC");
$id = (int)($_GET['id'] ?? 0);
$k = $id ? row("SELECT * FROM kegiatan WHERE id = ?", 'i', [$id]) : null;
if ($id && !$k) flash('error', 'Data kegiatan tidak ditemukan.');
$list = $k ? peserta($id) : []; $r = $k ? ringkas($list) : null;
include __DIR__ . '/../includes/header.php';
?>
<div class="panel mb-3 no-print">
  <form method="get" class="row g-2"><div class="col-md-7"><select name="id" class="form-select" required>
    <option value="">— Pilih kegiatan —</option>
    <?php foreach ($kegiatan as $x): ?><option value="<?= $x['id'] ?>" <?= $id === (int)$x['id'] ? 'selected' : '' ?>><?= e($x['nama_kegiatan']) ?> (<?= tgl($x['tanggal']) ?>)</option><?php endforeach; ?></select></div>
    <div class="col-md-5 d-flex gap-2"><button class="btn btn-primary">Tampilkan</button>
    <?php if ($k): ?><button type="button" class="btn btn-outline-primary" onclick="window.print()">Cetak</button><a class="btn btn-success" href="ekspor.php?id=<?= $id ?>">Ekspor CSV</a><?php endif; ?></div></form>
</div>
<?php if (!$k): ?><div class="panel text-muted">Pilih kegiatan untuk melihat rekapitulasi kehadiran.</div>
<?php else: ?>
<div class="panel">
  <h2 class="h5 fw-bold mb-0">Laporan Kehadiran: <?= e($k['nama_kegiatan']) ?></h2>
  <p class="text-muted"><?= tgl($k['tanggal']) ?>, <?= jam($k['jam_mulai']) ?>–<?= jam($k['jam_selesai']) ?> · <?= e($k['lokasi']) ?></p>
  <div class="row g-2 mb-3">
    <?php foreach ([['Peserta terdaftar', $r['total']], ['Hadir', $r['Hadir']], ['Tidak hadir', $r['tidak_hadir']], ['Persentase kehadiran', $r['persen'] . '%']] as [$l, $n]): ?>
    <div class="col-6 col-md-3"><div class="stat"><div class="n"><?= $n ?></div><div class="l"><?= $l ?></div></div></div><?php endforeach; ?>
  </div>
  <p class="small text-muted">Rincian tidak hadir: Izin <?= $r['Izin'] ?>, Sakit <?= $r['Sakit'] ?>, Alpa <?= $r['Alpa'] ?>, belum tercatat <?= $r['Belum'] ?>. Peserta = seluruh mahasiswa terdaftar.</p>
  <div class="table-responsive"><table class="table table-bordered align-middle">
    <thead><tr><th>No</th><th>NIM</th><th>Nama</th><th>Prodi</th><th>Status</th><th>Waktu absen</th><th>Metode</th></tr></thead><tbody>
    <?php foreach ($list as $i => $m): ?>
      <tr><td><?= $i + 1 ?></td><td><?= e($m['nim']) ?></td><td><?= e($m['nama']) ?></td><td><?= e($m['prodi'] ?: '-') ?></td><td><?= badge($m['status']) ?></td>
      <td><?= $m['waktu_absen'] ? date('d-m-Y H:i', strtotime($m['waktu_absen'])) : '-' ?></td><td><?= e($m['metode'] ?? '-') ?></td></tr>
    <?php endforeach; if (!$list): ?><tr><td colspan="7" class="text-center text-muted">Belum ada mahasiswa terdaftar.</td></tr><?php endif; ?>
    </tbody></table></div>
</div>
<?php endif; include __DIR__ . '/../includes/footer.php';
