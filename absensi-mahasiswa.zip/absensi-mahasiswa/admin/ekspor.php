<?php
require __DIR__ . '/../includes/functions.php';
cek_login();
$id = (int)($_GET['id'] ?? 0);
$k = row("SELECT * FROM kegiatan WHERE id = ?", 'i', [$id]);
if (!$k) { flash('error', 'Data kegiatan tidak ditemukan, ekspor dibatalkan.'); redirect('rekap.php'); }
$list = peserta($id); $r = ringkas($list);
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="rekap-kegiatan-' . $id . '.csv"');
$o = fopen('php://output', 'w');
fwrite($o, "\xEF\xBB\xBF");                       // BOM agar Excel membaca UTF-8
fputcsv($o, ['Kegiatan', csv_aman($k['nama_kegiatan'])], ';');
fputcsv($o, ['Tanggal', tgl($k['tanggal'])], ';');
fputcsv($o, ['Hadir', $r['Hadir'], 'Tidak hadir', $r['tidak_hadir'], 'Persentase', $r['persen'] . '%'], ';');
fputcsv($o, [], ';');
fputcsv($o, ['No', 'NIM', 'Nama', 'Prodi', 'Status', 'Waktu Absen', 'Metode'], ';');
foreach ($list as $i => $m) fputcsv($o, [$i + 1, csv_aman($m['nim']), csv_aman($m['nama']), csv_aman($m['prodi']), $m['status'] ?? 'Belum tercatat', $m['waktu_absen'] ?? '', $m['metode'] ?? ''], ';');
fclose($o);
