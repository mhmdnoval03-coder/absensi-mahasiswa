<?php
require __DIR__ . '/../includes/functions.php';
cek_login();
$aksi = $_GET['aksi'] ?? '';
$form = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $a = $_POST['aksi'] ?? '';
    $id = (int)($_POST['id'] ?? 0);
    if ($a === 'hapus') {
        try {
            $r = q("DELETE FROM mahasiswa WHERE id = ?", 'i', [$id]);
            $r->affected_rows ? flash('success', 'Data mahasiswa berhasil dihapus.') : flash('error', 'Data mahasiswa tidak ditemukan.');
        } catch (mysqli_sql_exception $e) {
            flash('error', $e->getCode() == 1451 ? 'Mahasiswa tidak bisa dihapus karena sudah memiliki data absensi.' : 'Gagal menghapus data mahasiswa.');
        }
        redirect('mahasiswa.php');
    }
    if ($a === 'simpan') {
        $d = ['nim' => trim($_POST['nim'] ?? ''), 'nama' => trim($_POST['nama'] ?? ''), 'email' => trim($_POST['email'] ?? ''), 'prodi' => trim($_POST['prodi'] ?? '')];
        $err = [];
        if ($d['nim'] === '') $err[] = 'NIM wajib diisi.';
        elseif (!preg_match('/^[0-9A-Za-z]{5,20}$/', $d['nim'])) $err[] = 'NIM harus 5–20 karakter berupa huruf atau angka.';
        if ($d['nama'] === '') $err[] = 'Nama tidak boleh kosong.';
        elseif (panjang($d['nama']) > 100) $err[] = 'Nama maksimal 100 karakter.';
        if ($d['email'] !== '' && !filter_var($d['email'], FILTER_VALIDATE_EMAIL)) $err[] = 'Format email tidak benar.';
        if (!$err && row("SELECT id FROM mahasiswa WHERE nim = ? AND id <> ?", 'si', [$d['nim'], $id])) $err[] = 'NIM sudah terdaftar. Gunakan NIM yang lain.';
        if (!$err) {
            try {
                $em = $d['email'] === '' ? null : $d['email'];
                if ($id) {
                    q("UPDATE mahasiswa SET nim=?, nama=?, email=?, prodi=? WHERE id=?", 'ssssi', [$d['nim'], $d['nama'], $em, $d['prodi'], $id]);
                    flash('success', 'Data mahasiswa berhasil diperbarui.');
                } else {
                    q("INSERT INTO mahasiswa (nim, nama, email, prodi) VALUES (?,?,?,?)", 'ssss', [$d['nim'], $d['nama'], $em, $d['prodi']]);
                    flash('success', 'Data mahasiswa berhasil ditambahkan.');
                }
                redirect('mahasiswa.php');
            } catch (mysqli_sql_exception $e) {
                $err[] = $e->getCode() == 1062 ? 'NIM sudah terdaftar. Gunakan NIM yang lain.' : 'Gagal menyimpan data. Silakan coba lagi.';
            }
        }
        flash('error', implode("\n", $err));
        $form = $d; $aksi = 'form'; $_GET['id'] = $id;
    }
}

$judul = 'Manajemen Mahasiswa'; $aktif = 'mahasiswa.php';
if ($aksi === 'form') {
    $id = (int)($_GET['id'] ?? 0);
    if ($form === null) {
        $form = ['nim' => '', 'nama' => '', 'email' => '', 'prodi' => ''];
        if ($id) {
            $r = row("SELECT * FROM mahasiswa WHERE id = ?", 'i', [$id]);
            if (!$r) { flash('error', 'Data mahasiswa tidak ditemukan.'); redirect('mahasiswa.php'); }
            $form = $r;
        }
    }
    include __DIR__ . '/../includes/header.php';
?>
<div class="panel" style="max-width:640px">
<h2 class="h5 fw-bold mb-3"><?= $id ? 'Edit mahasiswa' : 'Tambah mahasiswa' ?></h2>
<form method="post" class="needs-validation" novalidate>
  <input type="hidden" name="aksi" value="simpan"><input type="hidden" name="id" value="<?= $id ?>">
  <div class="mb-3"><label class="form-label">NIM</label>
    <input name="nim" class="form-control" required pattern="[0-9A-Za-z]{5,20}" maxlength="20" value="<?= e($form['nim']) ?>">
    <div class="invalid-feedback">NIM wajib diisi (5–20 huruf/angka).</div></div>
  <div class="mb-3"><label class="form-label">Nama lengkap</label>
    <input name="nama" class="form-control" required maxlength="100" value="<?= e($form['nama']) ?>">
    <div class="invalid-feedback">Nama wajib diisi.</div></div>
  <div class="mb-3"><label class="form-label">Email (opsional)</label>
    <input type="email" name="email" class="form-control" maxlength="100" value="<?= e($form['email']) ?>">
    <div class="invalid-feedback">Format email tidak benar.</div></div>
  <div class="mb-4"><label class="form-label">Program studi</label><input name="prodi" class="form-control" maxlength="100" value="<?= e($form['prodi']) ?>"></div>
  <button class="btn btn-primary">Simpan mahasiswa</button> <a href="mahasiswa.php" class="btn btn-outline-secondary">Batal</a>
</form></div>
<?php include __DIR__ . '/../includes/footer.php'; exit; }

$cari = trim($_GET['q'] ?? '');
$list = rows("SELECT * FROM mahasiswa WHERE nim LIKE ? OR nama LIKE ? OR prodi LIKE ? ORDER BY nim", 'sss', ["%$cari%", "%$cari%", "%$cari%"]);
include __DIR__ . '/../includes/header.php';
?>
<div class="panel">
  <form class="row g-2 mb-3" method="get">
    <div class="col-md-6"><input name="q" class="form-control" placeholder="Cari NIM, nama, atau prodi" value="<?= e($cari) ?>"></div>
    <div class="col-md-6 d-flex gap-2"><button class="btn btn-primary">Cari</button><a href="mahasiswa.php" class="btn btn-outline-secondary">Reset</a>
      <a href="mahasiswa.php?aksi=form" class="btn btn-success ms-auto">+ Tambah</a></div>
  </form>
  <div class="table-responsive"><table class="table align-middle">
    <thead><tr><th>#</th><th>NIM</th><th>Nama</th><th>Email</th><th>Prodi</th><th>Aksi</th></tr></thead><tbody>
    <?php foreach ($list as $i => $m): ?>
      <tr><td><?= $i + 1 ?></td><td><?= e($m['nim']) ?></td><td class="fw-semibold"><?= e($m['nama']) ?></td><td><?= e($m['email'] ?: '-') ?></td><td><?= e($m['prodi'] ?: '-') ?></td>
      <td class="text-nowrap"><a class="btn btn-sm btn-outline-secondary" href="mahasiswa.php?aksi=form&id=<?= $m['id'] ?>">Edit</a>
        <form method="post" class="d-inline js-hapus" data-pesan="Mahasiswa yang sudah punya data absensi tidak dapat dihapus.">
          <input type="hidden" name="aksi" value="hapus"><input type="hidden" name="id" value="<?= $m['id'] ?>"><button class="btn btn-sm btn-outline-danger">Hapus</button></form></td></tr>
    <?php endforeach; if (!$list): ?><tr><td colspan="6" class="text-center text-muted py-4">Data mahasiswa tidak ditemukan.</td></tr><?php endif; ?>
    </tbody></table></div>
</div>
<?php include __DIR__ . '/../includes/footer.php';
