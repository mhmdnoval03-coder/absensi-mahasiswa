<?php
require __DIR__ . '/../includes/functions.php';
cek_login();
$id = (int)($_GET['id'] ?? 0);
$k = row("SELECT * FROM kegiatan WHERE id = ?", 'i', [$id]);
if (!$k) { flash('error', 'Data kegiatan tidak ditemukan.'); redirect('kegiatan.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $a = $_POST['aksi'] ?? '';
    try {
        if ($a === 'status') {
            $baru = $k['status'] === 'dibuka' ? 'ditutup' : 'dibuka';
            q("UPDATE kegiatan SET status = ? WHERE id = ?", 'si', [$baru, $id]);
            flash('success', "Kegiatan sekarang berstatus $baru.");
        } elseif ($a === 'set') {
            $mid = (int)($_POST['mahasiswa_id'] ?? 0); $st = $_POST['status'] ?? '';
            if (!in_array($st, STATUS_HADIR, true) || !row("SELECT id FROM mahasiswa WHERE id = ?", 'i', [$mid])) {
                flash('error', 'Data absensi tidak valid.');
            } else {
                q("INSERT INTO absensi (kegiatan_id, mahasiswa_id, status, metode) VALUES (?,?,?,'Manual')
                   ON DUPLICATE KEY UPDATE status = VALUES(status)", 'iis', [$id, $mid, $st]);
                flash('success', 'Status kehadiran berhasil disimpan.');
            }
        } elseif ($a === 'reset') {
            q("DELETE FROM absensi WHERE kegiatan_id = ? AND mahasiswa_id = ?", 'ii', [$id, (int)($_POST['mahasiswa_id'] ?? 0)]);
            flash('success', 'Catatan kehadiran dihapus.');
        }
    } catch (mysqli_sql_exception $e) { flash('error', 'Gagal menyimpan data. Silakan coba lagi.'); }
    redirect("detail.php?id=$id");
}

$list = peserta($id); $r = ringkas($list);
$judul = 'Detail Kegiatan'; $aktif = 'kegiatan.php';
include __DIR__ . '/../includes/header.php';
?>
<div class="panel mb-3">
  <div class="d-flex flex-wrap gap-2 align-items-start">
    <div><h2 class="h5 fw-bold mb-1"><?= e($k['nama_kegiatan']) ?> <?= badge($k['status']) ?></h2>
      <div class="text-muted"><?= tgl($k['tanggal']) ?>, <?= jam($k['jam_mulai']) ?>–<?= jam($k['jam_selesai']) ?> · <?= e($k['lokasi']) ?></div>
      <?php if ($k['deskripsi']): ?><p class="mb-0 mt-2"><?= nl2br(e($k['deskripsi'])) ?></p><?php endif; ?></div>
    <div class="ms-auto d-flex gap-2 no-print">
      <a class="btn btn-outline-dark" href="qr.php?id=<?= $id ?>">QR Code</a>
      <form method="post"><input type="hidden" name="aksi" value="status">
        <button class="btn btn-<?= $k['status'] === 'dibuka' ? 'warning' : 'success' ?>"><?= $k['status'] === 'dibuka' ? 'Tutup kegiatan' : 'Buka kegiatan' ?></button></form>
    </div>
  </div>
  <hr><div class="d-flex flex-wrap gap-3">
    <span>Hadir: <b><?= $r['Hadir'] ?></b></span><span>Izin: <b><?= $r['Izin'] ?></b></span><span>Sakit: <b><?= $r['Sakit'] ?></b></span>
    <span>Alpa: <b><?= $r['Alpa'] ?></b></span><span>Belum tercatat: <b><?= $r['Belum'] ?></b></span><span>Kehadiran: <b><?= $r['persen'] ?>%</b></span>
  </div>
</div>
<div class="panel"><h2 class="h6 fw-bold">Peserta dan absensi manual</h2>
  <div class="table-responsive"><table class="table align-middle">
    <thead><tr><th>NIM</th><th>Nama</th><th>Status</th><th>Waktu</th><th>Metode</th><th class="no-print">Ubah status</th></tr></thead><tbody>
    <?php foreach ($list as $m): ?>
      <tr><td><?= e($m['nim']) ?></td><td><?= e($m['nama']) ?></td><td><?= badge($m['status']) ?></td>
      <td><?= $m['waktu_absen'] ? date('d-m-Y H:i', strtotime($m['waktu_absen'])) : '-' ?></td><td><?= e($m['metode'] ?? '-') ?></td>
      <td class="no-print"><form method="post" class="d-flex gap-1"><input type="hidden" name="aksi" value="set"><input type="hidden" name="mahasiswa_id" value="<?= $m['id'] ?>">
        <select name="status" class="form-select form-select-sm" style="width:110px"><?php foreach (STATUS_HADIR as $s): ?><option <?= $m['status'] === $s ? 'selected' : '' ?>><?= $s ?></option><?php endforeach; ?></select>
        <button class="btn btn-sm btn-primary">Simpan</button></form></td></tr>
    <?php endforeach; if (!$list): ?><tr><td colspan="6" class="text-center text-muted py-4">Belum ada mahasiswa terdaftar.</td></tr><?php endif; ?>
    </tbody></table></div>
</div>
<?php include __DIR__ . '/../includes/footer.php';
