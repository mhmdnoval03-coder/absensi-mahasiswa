<?php
require __DIR__ . '/../includes/functions.php';
cek_login();
$id = (int)($_GET['id'] ?? 0);
$k = row("SELECT * FROM kegiatan WHERE id = ?", 'i', [$id]);
if (!$k) { flash('error', 'Data kegiatan tidak ditemukan.'); redirect('kegiatan.php'); }
$t = row("SELECT token FROM qr_tokens WHERE kegiatan_id = ?", 'i', [$id]);
if (!$t) { $t = ['token' => bin2hex(random_bytes(16))]; q("INSERT INTO qr_tokens (kegiatan_id, token) VALUES (?,?)", 'is', [$id, $t['token']]); }
$skema = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$link = $skema . '://' . $_SERVER['HTTP_HOST'] . url('mahasiswa/absen.php?token=' . $t['token']);
$judul = 'QR Code Kegiatan'; $aktif = 'kegiatan.php'; $libs = ['qrcode.min.js'];
include __DIR__ . '/../includes/header.php';
?>
<div class="panel text-center" style="max-width:560px">
  <h2 class="h5 fw-bold"><?= e($k['nama_kegiatan']) ?></h2>
  <p class="text-muted"><?= tgl($k['tanggal']) ?> · <?= e($k['lokasi']) ?> <?= badge($k['status']) ?></p>
  <div id="qrbox"></div>
  <p class="small text-muted mt-3 mb-1">Tautan absensi:</p>
  <code class="small d-block text-break"><?= e($link) ?></code>
  <div class="no-print mt-3 d-flex gap-2 justify-content-center">
    <button class="btn btn-primary" onclick="window.print()">Cetak</button>
    <button class="btn btn-outline-primary" id="unduh">Unduh PNG</button>
    <a href="kegiatan.php" class="btn btn-outline-secondary">Kembali</a>
  </div>
  <p class="small text-muted mt-3 mb-0 no-print">Agar bisa dipindai dari HP, buka halaman admin ini lewat alamat IP laptop (misalnya <code>http://192.168.1.5<?= e(BASE_PATH) ?></code>), bukan <code>localhost</code>, dan pastikan HP satu jaringan Wi-Fi.</p>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
  var box = document.getElementById('qrbox');
  new QRCode(box, {text: <?= json_encode($link) ?>, width: 256, height: 256, correctLevel: QRCode.CorrectLevel.M});
  document.getElementById('unduh').addEventListener('click', function () {
    var c = box.querySelector('canvas'), a = document.createElement('a');
    a.href = c.toDataURL('image/png'); a.download = 'qr-kegiatan-<?= $id ?>.png'; a.click();
  });
});
</script>
<?php include __DIR__ . '/../includes/footer.php';
