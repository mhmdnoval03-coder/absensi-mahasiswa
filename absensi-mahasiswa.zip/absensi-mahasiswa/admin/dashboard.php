<?php
require __DIR__ . '/../includes/functions.php';
$judul = 'Dashboard'; $aktif = 'dashboard.php'; $libs = ['chart.umd.js'];
$s = [
  'kegiatan' => row("SELECT COUNT(*) n FROM kegiatan")['n'],
  'dibuka'   => row("SELECT COUNT(*) n FROM kegiatan WHERE status='dibuka'")['n'],
  'mhs'      => row("SELECT COUNT(*) n FROM mahasiswa")['n'],
  'hadir'    => row("SELECT COUNT(*) n FROM absensi WHERE status='Hadir'")['n'],
];
$perKegiatan = array_reverse(rows("SELECT k.nama_kegiatan nama, COUNT(a.id) hadir FROM kegiatan k
   LEFT JOIN absensi a ON a.kegiatan_id=k.id AND a.status='Hadir' GROUP BY k.id ORDER BY k.tanggal DESC LIMIT 6"));
$perStatus = rows("SELECT status, COUNT(*) n FROM absensi GROUP BY status");
$terbaru = rows("SELECT * FROM kegiatan ORDER BY tanggal DESC, jam_mulai DESC LIMIT 5");
include __DIR__ . '/../includes/header.php';
?>
<div class="row g-3 mb-4">
  <?php foreach ([['Total kegiatan', $s['kegiatan']], ['Kegiatan dibuka', $s['dibuka']], ['Mahasiswa terdaftar', $s['mhs']], ['Total kehadiran (Hadir)', $s['hadir']]] as [$l, $n]): ?>
  <div class="col-6 col-xl-3"><div class="stat"><div class="n"><?= $n ?></div><div class="l"><?= $l ?></div></div></div>
  <?php endforeach; ?>
</div>
<div class="row g-3 mb-4">
  <div class="col-lg-8"><div class="panel"><h2 class="h6 fw-bold">Peserta hadir per kegiatan</h2><canvas id="cBar" height="120"></canvas></div></div>
  <div class="col-lg-4"><div class="panel"><h2 class="h6 fw-bold">Komposisi status</h2>
    <?php if ($perStatus): ?><canvas id="cPie"></canvas><?php else: ?><p class="text-muted mb-0">Belum ada data absensi.</p><?php endif; ?></div></div>
</div>
<div class="panel"><h2 class="h6 fw-bold">Kegiatan terbaru</h2>
  <div class="table-responsive"><table class="table mb-0"><thead><tr><th>Kegiatan</th><th>Tanggal</th><th>Lokasi</th><th>Status</th><th></th></tr></thead><tbody>
  <?php foreach ($terbaru as $k): ?>
    <tr><td><?= e($k['nama_kegiatan']) ?></td><td><?= tgl($k['tanggal']) ?></td><td><?= e($k['lokasi']) ?></td><td><?= badge($k['status']) ?></td>
    <td><a class="btn btn-sm btn-outline-primary" href="detail.php?id=<?= $k['id'] ?>">Detail</a></td></tr>
  <?php endforeach; if (!$terbaru): ?><tr><td colspan="5" class="text-muted">Belum ada kegiatan.</td></tr><?php endif; ?>
  </tbody></table></div></div>
<script>
document.addEventListener('DOMContentLoaded', function () {
  new Chart(document.getElementById('cBar'), {type: 'bar',
    data: {labels: <?= json_encode(array_column($perKegiatan, 'nama')) ?>, datasets: [{label: 'Hadir', data: <?= json_encode(array_map('intval', array_column($perKegiatan, 'hadir'))) ?>, backgroundColor: '#1F4E8C'}]},
    options: {plugins: {legend: {display: false}}, scales: {y: {beginAtZero: true, ticks: {precision: 0}}}}});
  var p = document.getElementById('cPie');
  if (p) new Chart(p, {type: 'doughnut', data: {labels: <?= json_encode(array_column($perStatus, 'status')) ?>,
    datasets: [{data: <?= json_encode(array_map('intval', array_column($perStatus, 'n'))) ?>, backgroundColor: ['#2E8B57', '#2E86C1', '#D4A017', '#C0392B']}]}});
});
</script>
<?php include __DIR__ . '/../includes/footer.php';
