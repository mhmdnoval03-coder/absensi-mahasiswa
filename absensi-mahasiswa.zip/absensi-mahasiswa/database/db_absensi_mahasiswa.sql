-- Sistem Absensi Kegiatan Mahasiswa
CREATE DATABASE IF NOT EXISTS db_absensi_mahasiswa CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_absensi_mahasiswa;

DROP TABLE IF EXISTS absensi;
DROP TABLE IF EXISTS qr_tokens;
DROP TABLE IF EXISTS kegiatan;
DROP TABLE IF EXISTS mahasiswa;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(255) NOT NULL,
  nama_lengkap VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_users_username UNIQUE (username)
) ENGINE=InnoDB;

CREATE TABLE mahasiswa (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nim VARCHAR(20) NOT NULL,
  nama VARCHAR(100) NOT NULL,
  email VARCHAR(100) NULL,
  prodi VARCHAR(100) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_mahasiswa_nim UNIQUE (nim)
) ENGINE=InnoDB;

CREATE TABLE kegiatan (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nama_kegiatan VARCHAR(150) NOT NULL,
  deskripsi TEXT NULL,
  tanggal DATE NOT NULL,
  jam_mulai TIME NOT NULL,
  jam_selesai TIME NOT NULL,
  lokasi VARCHAR(150) NOT NULL,
  status ENUM('dibuka','ditutup') NOT NULL DEFAULT 'dibuka',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE qr_tokens (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kegiatan_id INT UNSIGNED NOT NULL,
  token VARCHAR(64) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_qr_kegiatan UNIQUE (kegiatan_id),
  CONSTRAINT uq_qr_token UNIQUE (token),
  CONSTRAINT fk_qr_kegiatan FOREIGN KEY (kegiatan_id) REFERENCES kegiatan(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE absensi (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  kegiatan_id INT UNSIGNED NOT NULL,
  mahasiswa_id INT UNSIGNED NOT NULL,
  status ENUM('Hadir','Izin','Sakit','Alpa') NOT NULL DEFAULT 'Hadir',
  waktu_absen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  metode ENUM('QR','Manual') NOT NULL DEFAULT 'QR',
  keterangan VARCHAR(255) NULL,
  CONSTRAINT uq_absensi_peserta UNIQUE (kegiatan_id, mahasiswa_id),
  CONSTRAINT fk_absensi_kegiatan FOREIGN KEY (kegiatan_id) REFERENCES kegiatan(id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_absensi_mahasiswa FOREIGN KEY (mahasiswa_id) REFERENCES mahasiswa(id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Data contoh untuk pengujian. Admin: username "admin", password "password"
INSERT INTO users (username, password, nama_lengkap) VALUES
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Administrator Panitia');

INSERT INTO mahasiswa (nim, nama, email, prodi) VALUES
('2022001', 'Contoh Mahasiswa Satu', 'mhs1@example.com', 'Sistem Informasi'),
('2022002', 'Contoh Mahasiswa Dua', 'mhs2@example.com', 'Sistem Informasi'),
('2022003', 'Contoh Mahasiswa Tiga', NULL, 'Teknik Informatika'),
('2022004', 'Contoh Mahasiswa Empat', 'mhs4@example.com', 'Teknik Informatika'),
('2022005', 'Contoh Mahasiswa Lima', NULL, 'Sistem Informasi');

INSERT INTO kegiatan (nama_kegiatan, deskripsi, tanggal, jam_mulai, jam_selesai, lokasi, status) VALUES
('Seminar Teknologi Informasi', 'Seminar contoh untuk pengujian.', '2026-11-10', '09:00:00', '12:00:00', 'Aula Kampus', 'dibuka'),
('Workshop Pemrograman Web', 'Workshop contoh untuk pengujian.', '2026-11-12', '13:00:00', '16:00:00', 'Lab Komputer 1', 'dibuka'),
('Pelatihan Kepanitiaan', 'Kegiatan contoh yang sudah ditutup.', '2026-10-20', '08:00:00', '11:00:00', 'Ruang Rapat', 'ditutup');

-- 20 kegiatan contoh tambahan
INSERT INTO kegiatan (nama_kegiatan, deskripsi, tanggal, jam_mulai, jam_selesai, lokasi, status) VALUES
('Orientasi Mahasiswa Baru 2026', 'Pengenalan kampus dan organisasi untuk mahasiswa baru.', '2026-08-24', '07:30:00', '15:00:00', 'Lapangan Utama', 'ditutup'),
('Pelatihan Kepemimpinan Mahasiswa', 'Pelatihan dasar kepemimpinan bagi pengurus organisasi.', '2026-09-05', '08:00:00', '16:00:00', 'Aula Kampus', 'ditutup'),
('Seminar Kewirausahaan Digital', 'Seminar tentang memulai usaha berbasis digital.', '2026-09-12', '09:00:00', '12:00:00', 'Aula Kampus', 'ditutup'),
('Workshop Desain UI/UX', 'Praktik merancang antarmuka aplikasi.', '2026-09-19', '13:00:00', '16:00:00', 'Lab Multimedia', 'ditutup'),
('Lomba Karya Tulis Ilmiah', 'Lomba karya tulis tingkat fakultas.', '2026-09-26', '08:00:00', '14:00:00', 'Ruang Seminar', 'ditutup'),
('Bakti Sosial Mahasiswa', 'Kegiatan pengabdian di desa binaan.', '2026-10-03', '07:00:00', '12:00:00', 'Desa Binaan', 'ditutup'),
('Pelatihan Public Speaking', 'Latihan berbicara di depan umum dan presentasi.', '2026-10-10', '13:00:00', '16:00:00', 'Ruang Rapat', 'ditutup'),
('Kuliah Umum Keamanan Siber', 'Kuliah umum bersama praktisi keamanan informasi.', '2026-10-17', '09:00:00', '11:30:00', 'Aula Kampus', 'ditutup'),
('Donor Darah Mahasiswa', 'Kegiatan donor darah bekerja sama dengan PMI.', '2026-10-24', '08:00:00', '13:00:00', 'Gedung Serbaguna', 'ditutup'),
('Turnamen Futsal Antar Prodi', 'Pertandingan futsal antar program studi.', '2026-10-31', '08:00:00', '17:00:00', 'Lapangan Futsal', 'ditutup'),
('Seminar Nasional Teknologi', 'Seminar nasional dengan pembicara dari industri.', '2026-11-14', '08:30:00', '13:00:00', 'Aula Kampus', 'dibuka'),
('Workshop Git dan GitHub', 'Pengenalan version control untuk kerja tim.', '2026-11-18', '13:00:00', '16:00:00', 'Lab Komputer 2', 'dibuka'),
('Pelatihan Data Analitik dengan Excel', 'Pengolahan dan visualisasi data menggunakan Excel.', '2026-11-21', '09:00:00', '12:00:00', 'Lab Komputer 1', 'dibuka'),
('Bedah Karier: Alumni Berbagi', 'Alumni berbagi pengalaman memasuki dunia kerja.', '2026-11-25', '13:00:00', '15:30:00', 'Ruang Seminar', 'dibuka'),
('Hackathon Kampus', 'Lomba membuat aplikasi dalam waktu singkat.', '2026-11-28', '08:00:00', '20:00:00', 'Lab Komputer 1', 'dibuka'),
('Pelatihan Penulisan Jurnal', 'Teknik menulis artikel ilmiah untuk jurnal.', '2026-12-05', '09:00:00', '12:00:00', 'Ruang Seminar', 'dibuka'),
('Rapat Kerja Organisasi Mahasiswa', 'Penyusunan program kerja semester genap.', '2026-12-12', '09:00:00', '15:00:00', 'Ruang Rapat', 'dibuka'),
('Malam Keakraban Mahasiswa', 'Acara kebersamaan antar angkatan.', '2026-12-19', '18:00:00', '22:00:00', 'Gedung Serbaguna', 'dibuka'),
('Workshop Pengembangan Aplikasi Mobile', 'Dasar pembuatan aplikasi mobile.', '2027-01-16', '09:00:00', '16:00:00', 'Lab Multimedia', 'dibuka'),
('Pelepasan Mahasiswa KKN', 'Acara pelepasan peserta Kuliah Kerja Nyata.', '2027-01-30', '08:00:00', '11:00:00', 'Aula Kampus', 'dibuka');

-- Token QR untuk kegiatan contoh (acak, 32 karakter hex)
INSERT INTO qr_tokens (kegiatan_id, token) SELECT id, REPLACE(UUID(), '-', '') FROM kegiatan;
