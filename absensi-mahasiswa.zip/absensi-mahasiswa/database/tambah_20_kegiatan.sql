-- Tambahan 20 kegiatan contoh. Jalankan di phpMyAdmin (tab SQL) pada database db_absensi_mahasiswa.
USE db_absensi_mahasiswa;
INSERT INTO kegiatan (nama_kegiatan, deskripsi, tanggal, jam_mulai, jam_selesai, lokasi, status) VALUES
('Orientasi Mahasiswa Baru 2026', 'Pengenalan kampus dan organisasi untuk mahasiswa baru.', '2026-08-24', '07:30:00', '15:00:00', 'Lapangan Utama', 'ditutup'),
('Pelatihan Kepemimpinan Mahasiswa', 'Pelatihan dasar kepemimpinan bagi pengurus organisasi.', '2026-09-05', '08:00:00', '16:00:00', 'Aula Kampus', 'ditutup'),
('Seminar Kewirausahaan Digital', 'Seminar tentang memulai usaha berbasis digital.', '2026-09-12', '09:00:00', '12:00:00', 'Aula Kampus', 'ditutup'),
('Workshop Desain UI/UX', 'Praktik merancang antarmuka aplikasi.', '2026-09-19', '13:00:00', '16:00:00', 'Lab Multimedia', 'ditutup'),
('Lomba Karya Tulis Ilmiah', 'Lomba karya tulis tingkat fakultas.', '2026-09-26', '08:00:00', '14:00:00', 'Ruang Seminar', 'ditutup'),
('Bakti Sosial Mahasiswa', 'Kegiatan pengabdian di desa binaan.', '2026-10-03', '07:00:00', '12:00:00', 'Desa Binaan', 'ditutup'),
('Pelatihan Public Speaking', 'Latihan berbicara di depan umum dan presentasi.', '2026-10-10', '13:00:00', '16:00:00', 'Ruang Rapat', 'ditutup'),
('Kuliah Umum Keamanan Siber', 'Kuliah umum bersama praktisi keamanan informasi.', '2026-10-17', '09:00:00', '11:30:00', 'Aula Kampus', 'ditutup'),
('Donor Darah Mahasiswa', 'Kegiatan donor darah bekerja sama dengan PMI.', '2026-10-24', '08:00:00', '13:00:00', 'Gedung Serbaguna', 'ditutup'),
('Turnamen Futsal Antar Prodi', 'Pertandingan futsal antar program studi.', '2026-10-31', '08:00:00', '17:00:00', 'Lapangan Futsal', 'ditutup'),
('Seminar Nasional Teknologi', 'Seminar nasional dengan pembicara dari industri.', '2026-11-14', '08:30:00', '13:00:00', 'Aula Kampus', 'dibuka'),
('Workshop Git dan GitHub', 'Pengenalan version control untuk kerja tim.', '2026-11-18', '13:00:00', '16:00:00', 'Lab Komputer 2', 'dibuka'),
('Pelatihan Data Analitik dengan Excel', 'Pengolahan dan visualisasi data menggunakan Excel.', '2026-11-21', '09:00:00', '12:00:00', 'Lab Komputer 1', 'dibuka'),
('Bedah Karier: Alumni Berbagi', 'Alumni berbagi pengalaman memasuki dunia kerja.', '2026-11-25', '13:00:00', '15:30:00', 'Ruang Seminar', 'dibuka'),
('Hackathon Kampus', 'Lomba membuat aplikasi dalam waktu singkat.', '2026-11-28', '08:00:00', '20:00:00', 'Lab Komputer 1', 'dibuka'),
('Pelatihan Penulisan Jurnal', 'Teknik menulis artikel ilmiah untuk jurnal.', '2026-12-05', '09:00:00', '12:00:00', 'Ruang Seminar', 'dibuka'),
('Rapat Kerja Organisasi Mahasiswa', 'Penyusunan program kerja semester genap.', '2026-12-12', '09:00:00', '15:00:00', 'Ruang Rapat', 'dibuka'),
('Malam Keakraban Mahasiswa', 'Acara kebersamaan antar angkatan.', '2026-12-19', '18:00:00', '22:00:00', 'Gedung Serbaguna', 'dibuka'),
('Workshop Pengembangan Aplikasi Mobile', 'Dasar pembuatan aplikasi mobile.', '2027-01-16', '09:00:00', '16:00:00', 'Lab Multimedia', 'dibuka'),
('Pelepasan Mahasiswa KKN', 'Acara pelepasan peserta Kuliah Kerja Nyata.', '2027-01-30', '08:00:00', '11:00:00', 'Aula Kampus', 'dibuka');

-- Buat token QR untuk kegiatan yang belum punya token
INSERT INTO qr_tokens (kegiatan_id, token) SELECT k.id, REPLACE(UUID(), '-', '') FROM kegiatan k LEFT JOIN qr_tokens t ON t.kegiatan_id = k.id WHERE t.id IS NULL;
