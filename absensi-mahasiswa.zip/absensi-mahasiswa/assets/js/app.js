// Konfirmasi hapus dengan SweetAlert2
document.querySelectorAll('form.js-hapus').forEach(function (f) {
  f.addEventListener('submit', function (e) {
    e.preventDefault();
    Swal.fire({
      title: 'Hapus data?', text: f.dataset.pesan || 'Data yang dihapus tidak dapat dikembalikan.',
      icon: 'warning', showCancelButton: true, confirmButtonText: 'Ya, hapus',
      cancelButtonText: 'Batal', confirmButtonColor: '#C0392B'
    }).then(function (r) { if (r.isConfirmed) f.submit(); });
  });
});
// Validasi form sisi klien (Bootstrap)
document.querySelectorAll('form.needs-validation').forEach(function (f) {
  f.addEventListener('submit', function (e) {
    if (!f.checkValidity()) { e.preventDefault(); e.stopPropagation(); }
    f.classList.add('was-validated');
  });
});
var tb = document.getElementById('toggleSidebar');
if (tb) tb.addEventListener('click', function () { document.body.classList.toggle('side-open'); });
